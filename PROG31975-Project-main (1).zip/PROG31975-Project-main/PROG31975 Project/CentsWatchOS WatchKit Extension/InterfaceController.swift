//
//  SpendingView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import WatchConnectivity

// handles incoming messages from iOS to watchOS
class InterfaceController : NSObject, WCSessionDelegate, ObservableObject {
    
    // creates a session
    var session: WCSession

    // holds the value for the total spending
    @Published var total: Int = 0
    
    // initalizes session
    init(session: WCSession = .default){
        self.session = session
        super.init()
        self.session.delegate = self
        session.activate()
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    // function that handles recieved messages
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        
        DispatchQueue.main.async {

            // sets the variable for spending total to value of incoming message
            self.total = message["message"] as? Int ?? 0

        }
    }

}
