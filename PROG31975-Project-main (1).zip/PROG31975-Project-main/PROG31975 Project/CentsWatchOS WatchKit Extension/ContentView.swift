//
//  SpendingView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//
import SwiftUI

// controls interface of the watchOS application
struct ContentView: View {

    // instance of InterfaceController class
    @ObservedObject var model = InterfaceController()
    
    var body: some View {
        
        VStack {
            
            // displays total spending for the logged in user
            Text("Total spending:")
            Text("$\(self.model.total)")
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
