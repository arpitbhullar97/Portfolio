//
//  SpendingView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import WatchConnectivity

// class that connects watchos to iOS app
class WatchOSController : NSObject,  WCSessionDelegate, ObservableObject{
    
    // creates a session
    var session: WCSession

    // session initializer
    init(session: WCSession = .default) {
    self.session = session
    super.init()
    session.delegate = self
    session.activate()
    }
    
    // session function that allows for communication
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {

    }
  
// only runs on iOS application
#if os(iOS)
public func sessionDidBecomeInactive(_ session: WCSession) { }
public func sessionDidDeactivate(_ session: WCSession) {
    session.activate()
}
#endif
    
}
