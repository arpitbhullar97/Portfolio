//
//  PROG31975_ProjectApp.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//

import SwiftUI
import Firebase
import FirebaseFirestore

@main
struct PROG31975_ProjectApp: App {
    let persistenceController = PersistenceController.shared
    
    let fireDBHelper : FireDBHelper
    
    @StateObject var selectedLocation = SelectedLocation()
    @StateObject var loginManager = LoginManager()
    
    init() {
        FirebaseApp.configure()
        fireDBHelper = FireDBHelper(database: Firestore.firestore())
      }

    var body: some Scene {
        WindowGroup {
            NavigationBarView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                .environmentObject(selectedLocation)
                .environmentObject(fireDBHelper)
                .environmentObject(loginManager)
                
        }
    }
}
