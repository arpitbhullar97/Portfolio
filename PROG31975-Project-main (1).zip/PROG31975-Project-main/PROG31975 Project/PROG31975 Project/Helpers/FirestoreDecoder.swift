//
//  FirestoreDecoder.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Firebase
import FirebaseFirestoreSwift

// decoder for the database to allow for queries
struct FirestoreDecoder<T: Codable> {
    
    // function that recieves the query and returns the result
    static func getCodables(for query: Query, completion: @escaping (Result<[T], Error>) -> ()) {
        
        // gets the document form the database based on query
        query.getDocuments {querySnapshot, err in
            if let err = err {
                completion(.failure(err))
                return
            }
            
            guard let querySnapshot = querySnapshot else {
                completion(.failure(err!))
                return
            }
            
            // stores the query result in objects variable
            let objects = querySnapshot.documents.compactMap { document in
                try? document.data(as: T.self)
            }
            
            completion(.success(objects))
            
        }
        
    }
    
}
