//
//  FireDBHelper.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import FirebaseFirestore

// class that controls firebase management
class FireDBHelper: ObservableObject{
    
    // variable that holds a list of the transactions
    @Published var transactionList = [Transaction]()
    @Published var paymentList = [Payment]()
    private let COLLECTION_NAME : String = "Transactions"
    private let COLLECTION_NAME2 : String = "Payments"
    private let store : Firestore
    
    private static var shared : FireDBHelper?
    
    // generates an instance of the FireDBHelper class
    static func getInstance() -> FireDBHelper {
        if shared == nil{
            shared = FireDBHelper(database: Firestore.firestore())
        }
        return shared!
    }
    
    // initializes the firestore database
    init(database : Firestore){
        self.store = database
    }
    
    // function that handles insertion into the database
    func insertTransaction(newTransaction: Transaction){
        do {
            try self.store.collection(COLLECTION_NAME).addDocument(from: newTransaction)
        } catch let error as NSError{
            print(#function, "Error while inserting the task", error)
        }
    }
    
    // function that handles insertion into the database
    func insertPayment(newPayment: Payment){
        do {
            try self.store.collection(COLLECTION_NAME2).addDocument(from: newPayment)
        } catch let error as NSError{
            print(#function, "Error while inserting the task", error)
        }
    }
    
    // function that retrieves all transactions in the firestore database
    func getAllTransactions(){
            self.store.collection(COLLECTION_NAME)
        
                // orders the collection by the date each transaction was created
                .order(by: "dateCreated", descending: true)
                .addSnapshotListener({(querySnapshot, error) in
                    guard let snapshot = querySnapshot else{
                        
                        // display error message if snapshop of documents could not be retrieved
                        print(#function, "Error getting the snapshot of the documents", error)
                        return
                    }
                    
                    self.transactionList.removeAll()
                    
                    // on snapshot document change
                    snapshot.documentChanges.forEach{ (docChange) in
                        
                        var transaction = Transaction()
                        
                        do{
                            transaction = try docChange.document.data(as: Transaction.self)!
                            
                            // if a transaction has been added, append it to the list
                            if docChange.type == .added{
                                self.transactionList.append(transaction)
                                print(#function, "New document added : ", transaction)
                            }
                            
                            // if the added transaction matches one already in the database, replace it
                            if docChange.type == .modified{
                                let docId = docChange.document.documentID
                                
                                let matchedIndex = self.transactionList.firstIndex(where: {($0.id?.elementsEqual(docId))!})
                                if (matchedIndex != nil){
                                    self.transactionList[matchedIndex!] = transaction
                                }
                            }
                            
                            // handles removal from the database
                            if docChange.type == .removed{
                                let docId = docChange.document.documentID
                                
                                let matchedIndex = self.transactionList.firstIndex(where: {($0.id?.elementsEqual(docId))!})
                                if (matchedIndex != nil){
                                    self.transactionList.remove(at: matchedIndex!)
                                }
                            }
                            
                        } catch let error as NSError{
                            print(#function, "error while gettting document change", error)
                        }
                    }
                })
    }
    
    
    // function that retrieves all transactions in the firestore database
    func getAllPayments(){
            self.store.collection(COLLECTION_NAME2)
        
                // orders the collection by the date each transaction was created
                .order(by: "dateCreated", descending: true)
                .addSnapshotListener({(querySnapshot, error) in
                    guard let snapshot = querySnapshot else{
                        
                        // display error message if snapshop of documents could not be retrieved
                        print(#function, "Error getting the snapshot of the documents", error)
                        return
                    }
                    
                    self.paymentList.removeAll()
                    
                    // on snapshot document change
                    snapshot.documentChanges.forEach{ (docChange) in
                        
                        var payment = Payment()
                        
                        do{
                            payment = try docChange.document.data(as: Payment.self)!
                            
                            // if a transaction has been added, append it to the list
                            if docChange.type == .added{
                                self.paymentList.append(payment)
                                print(#function, "New document added : ", payment)
                            }
                            
                            // if the added transaction matches one already in the database, replace it
                            if docChange.type == .modified{
                                let docId = docChange.document.documentID
                                
                                let matchedIndex = self.transactionList.firstIndex(where: {($0.id?.elementsEqual(docId))!})
                                if (matchedIndex != nil){
                                    self.paymentList[matchedIndex!] = payment
                                }
                            }
                            
                            // handles removal from the database
                            if docChange.type == .removed{
                                let docId = docChange.document.documentID
                                
                                let matchedIndex = self.paymentList.firstIndex(where: {($0.id?.elementsEqual(docId))!})
                                if (matchedIndex != nil){
                                    self.paymentList.remove(at: matchedIndex!)
                                }
                            }
                            
                        } catch let error as NSError{
                            print(#function, "error while gettting document change", error)
                        }
                    }
                })
    }

}
