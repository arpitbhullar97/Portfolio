//
//  LocationHelper.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import MapKit

// class that manages accuracy of the users location
class LocationHelper: NSObject, ObservableObject {
    
    private let locationHelper = CLLocationManager()
    @Published var location: CLLocation? = nil
    
    // initializes the delegate, location accuracy, and distance filter
    override init() {
        
        super.init()
        self.locationHelper.delegate = self
        self.locationHelper.desiredAccuracy = kCLLocationAccuracyBest
        self.locationHelper.distanceFilter = kCLDistanceFilterNone
        self.locationHelper.requestWhenInUseAuthorization()
        self.locationHelper.startUpdatingLocation()
        
    }
    
}

// an extension of the location helper class
extension LocationHelper: CLLocationManagerDelegate {
    
    // function that detects if the user changed location authorization
    private func locationHelper(_ manager: CLLocationManager, didChangeAuthirozation status: CLAuthorizationStatus) {
        print(status)
    }
    
    // function that detects an update of user location
    func locationHelper(_ manager: CLLocationManager, didUpdateLocation locations: [CLLocation]) {
        guard let location = locations.last else {
            return
        }
        
        self.location = location
        
    }
    
}
