//
//  FirestoreService.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI
import Firebase

// class that manages queries and sends them to Firestore Decoder
class FirestoreService<T: Codable> {
    
    static func query(_ query: Query, completion: @escaping (Result<[T], Error>) -> ()) {
        
        // calls firestore decoder class and sends it the query
        FirestoreDecoder<T>.getCodables(for: query, completion: completion)
        
    }
    
}
