//
//  Transactions.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import FirebaseFirestoreSwift

// transaction model which contains date, category, cost, etc. of each transaction
struct Transaction : Codable, Identifiable, Hashable{
    @DocumentID var id : String? = UUID().uuidString
    var user : String = ""
    var date : String = ""
    var category : String = ""
    var budget : String = ""
    var cost : Int = 0
    var location : String = ""
    var dateCreated : Date = Date()
    
    init() {
        
    }
    
    // initialize each property
    init(user: String, date: String, category: String, budget: String, cost: Int, location: String){
        self.user = user
        self.date = date
        self.category = category
        self.budget = budget
        self.cost = cost
        self.location = location
        self.dateCreated = Date()
    }
    
    // initilizes each property including date created
    init(user: String, date: String, category: String, budget: String, cost: Int, location: String, dateCreated: Date){
        self.user = user
        self.date = date
        self.category = category
        self.budget = budget
        self.cost = cost
        self.location = location
        self.dateCreated = Date()
    }
    
    //initializer used to parse JSON objects into Swift objects
    // dictionary where key is a string and value is any type
    init?(dictionary: [String: Any]){
        guard let user = dictionary["user"] as? String else {
            return nil
        }
        guard let date = dictionary["date"] as? String else{
            return nil
        }
        
        guard let category = dictionary["category"] as? String else{
            return nil
        }
        
        guard let budget = dictionary["budget"] as? String else{
            return nil
        }
        
        guard let cost = dictionary["cost"] as? Int else{
            return nil
        }
        
        guard let location = dictionary["location"] as? String else{
            return nil
        }
        
        guard let dateCreated = dictionary["dateCreated"] as? Date else {
            return nil
        }
        
        self.init(user: user, date: date, category: category, budget: budget, cost: cost, location: location, dateCreated: dateCreated)
    }
}
