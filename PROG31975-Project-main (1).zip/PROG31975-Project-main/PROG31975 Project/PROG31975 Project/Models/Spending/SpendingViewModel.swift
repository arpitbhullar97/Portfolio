//
//  SpendingViewModel.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI

// spending view model
class SpendingViewModel: ObservableObject {
    
    // creates array of type Transaction
    @Published var transactions: [Transaction] = []
    
    // function that contains the results of the query for the cost of all users in transaction collection
    func queryTotal(completion: @escaping (Error?) ->()) {
        TransactionCollection.queryTotal {result in
            switch result {
                case .success(let transactions):
                    self.transactions = transactions
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    // function that contains the results of the query for food category in transaction collection
    func queryFood(completion: @escaping (Error?) ->()) {
        TransactionCollection.queryFood {result in
            switch result {
                case .success(let transactions):
                    self.transactions = transactions
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    // function that contains the results of the query for housing category in transaction collection
    func queryHousing(completion: @escaping (Error?) ->()) {
        TransactionCollection.queryHousing { result in
            switch result {
                case .success(let transactions):
                    self.transactions = transactions
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    // function that contains the results of the query for transportation category in transaction collection
    func queryTransportation(completion: @escaping (Error?) ->()) {
        TransactionCollection.queryTransportation { result in
            switch result {
                case .success(let transactions):
                    self.transactions = transactions
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    // function that contains the results of the query for insurance category in transaction collection
    func queryInsurance(completion: @escaping (Error?) ->()) {
        TransactionCollection.queryInsurance { result in
            switch result {
                case .success(let transactions):
                    self.transactions = transactions
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    // function that contains the results of the query for personal category in transaction collection
    func queryPersonal(completion: @escaping (Error?) ->()) {
        TransactionCollection.queryPersonal { result in
            switch result {
                case .success(let transactions):
                    self.transactions = transactions
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    // function that contains the results of the query for budget category in transaction collection
    func queryBudget(completion: @escaping (Error?) ->()) {
        TransactionCollection.queryBudget { result in
            switch result {
                case .success(let transactions):
                    self.transactions = transactions
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
}
