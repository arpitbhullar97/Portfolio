//
//  TransactionCollection.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Firebase
import Foundation

// class that contains all database queries
class TransactionCollection {
    
    // path to collection in firebase
    private static let path: String = "Transactions"
    
    // query used to get all transactions from user
    static func queryTotal(completion: @escaping (Result<[Transaction], Error>) -> () = {_ in}) {
        let queryTotal = Firestore.firestore().collection(path).whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryTotal, completion: completion)
    }
    
    // query used to get all transactions with the category food
    static func queryFood(completion: @escaping (Result<[Transaction], Error>) -> () = {_ in}) {
        let queryFood = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "Food").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryFood, completion: completion)
    }
    
    // query used to get all transactions with the category housing
    static func queryHousing(completion: @escaping (Result<[Transaction], Error>) -> () = {_ in}) {
        let queryHousing = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "Housing").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryHousing, completion: completion)
    }
    
    // query used to get all transactions with the category transportation
    static func queryTransportation(completion: @escaping (Result<[Transaction], Error>) -> () = {_ in}) {
        let queryTransportation = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "Transportation").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryTransportation, completion: completion)
    }
    
    // query used to get all transactions with the category insurance
    static func queryInsurance(completion: @escaping (Result<[Transaction], Error>) -> () = {_ in}) {
        let queryInsurance = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "Insurance").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryInsurance, completion: completion)
    }
    
    // query used to get all transactions with the category personal
    static func queryPersonal(completion: @escaping (Result<[Transaction], Error>) -> () = {_ in}) {
        let queryPersonal = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "Personal").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryPersonal, completion: completion)
    }
    
    // query used to get all transactions with the category budget
    static func queryBudget(completion: @escaping (Result<[Transaction], Error>) -> () = {_ in}) {
        let queryBudget = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "Budget").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryBudget, completion: completion)
    }
    
}
