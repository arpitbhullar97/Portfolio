//
//  Landmark.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import MapKit

// struct that contains the landmark properties
struct Landmark {
    
    // variable that holds placemark
    let placemark: MKPlacemark
    
    // variable that holds ID for placemark
    var id: UUID {
        return UUID()
    }
    
    // variable that holds name of placemark
    var name: String {
        self.placemark.name ?? ""
    }
    
    // variable that holds title of placemark
    var title: String {
        self.placemark.title ?? ""
    }
    
    // variable that holds coordinates of placemark
    var coordinate: CLLocationCoordinate2D {
        self.placemark.coordinate
    }
    
}
