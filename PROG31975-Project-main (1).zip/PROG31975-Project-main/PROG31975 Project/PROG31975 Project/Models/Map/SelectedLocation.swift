//
//  SelectedLocation.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation

// class that contains the properties of the users selected location
class SelectedLocation: ObservableObject {
    
    // variable that holds the name of the selected location
    @Published var name : String = ""
    
    // variable that holds the title of the selected location
    @Published var title : String = ""
    
}
