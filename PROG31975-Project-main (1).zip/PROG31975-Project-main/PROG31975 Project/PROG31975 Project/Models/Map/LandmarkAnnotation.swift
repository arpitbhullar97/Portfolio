//
//  LandmarkAnnotation.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import MapKit
import UIKit

// class that contains the annocations for the landmark user selected
final class LandmarkAnnotation: NSObject, MKAnnotation {
    
    // variable that holds the title of the landmark
    let title: String?
    
    // variable that holds the coordinates of the landmark
    let coordinate: CLLocationCoordinate2D
    
    // initializes the landmark title and coordinates
    init (landmark: Landmark) {
        self.title = landmark.name
        self.coordinate = landmark.coordinate
    }
}
