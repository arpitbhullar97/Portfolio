//
//  Payment.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Arpit Bhullar
//

import Foundation
import FirebaseFirestoreSwift

// transaction model which contains date, category, amount, etc. of each transaction
struct Payment : Codable, Identifiable, Hashable{
    @DocumentID var id : String? = UUID().uuidString
    var user : String = ""
    var date : String = ""
    var category : String = ""
    var card : String = ""
    var amount : Int = 0
    var dateDue : Date = Date()
    
    init() {
        
    }
    
    // initialize each property
    init(user: String, date: String, category: String, card: String, amount: Int){
        self.user = user
        self.date = date
        self.category = category
        self.card = card
        self.amount = amount
    }
    
    // initilizes each property including date created
    init(user: String, date: String, category: String, card: String, amount: Int, dateDue: Date){
        self.user = user
        self.date = date
        self.category = category
        self.card = card
        self.amount = amount
        self.dateDue = Date()
    }
    
    //initializer used to parse JSON objects into Swift objects
    // dictionary where key is a string and value is any type
    init?(dictionary: [String: Any]){
        guard let user = dictionary["user"] as? String else {
            return nil
        }
        guard let date = dictionary["date"] as? String else{
            return nil
        }
        
        guard let category = dictionary["category"] as? String else{
            return nil
        }
        
        guard let card = dictionary["card"] as? String else{
            return nil
        }
        
        guard let amount = dictionary["amount"] as? Int else{
            return nil
        }
        
        
        guard let dateDue = dictionary["dateDue"] as? Date else {
            return nil
        }
        
        self.init(user: user, date: date, category: category, card: card, amount: amount, dateDue: dateDue)
    }
}
