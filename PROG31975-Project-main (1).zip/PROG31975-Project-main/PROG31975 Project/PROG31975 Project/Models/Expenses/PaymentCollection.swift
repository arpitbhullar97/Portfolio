//
// PaymentCollection.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Arpit Bhullar
//

import Firebase
import Foundation

// class that contains all database queries
class PaymentCollection {
    
    // path to collection in firebase
    private static let path: String = "Payments"
    
    // query used to get all transactions with the category food
    static func queryCredit(completion: @escaping (Result<[Payment], Error>) -> () = {_ in}) {
        let queryCredit = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "CreditCards").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryCredit, completion: completion)
    }
    
    
    // query used to get all transactions with the category insurance
    static func queryInsuranceDues(completion: @escaping (Result<[Payment], Error>) -> () = {_ in}) {
        let queryInsuranceDues = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "Insurance Dues").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryInsuranceDues, completion: completion)
    }
    
    // query used to get all transactions with the category personal
    static func queryOtherBills(completion: @escaping (Result<[Payment], Error>) -> () = {_ in}) {
        let queryOtherBills = Firestore.firestore().collection(path)
            .whereField("category", isEqualTo: "Other Bills").whereField("user", isEqualTo: Auth.auth().currentUser?.uid as Any)
        FirestoreService.query(queryOtherBills, completion: completion)
    }
    
}
