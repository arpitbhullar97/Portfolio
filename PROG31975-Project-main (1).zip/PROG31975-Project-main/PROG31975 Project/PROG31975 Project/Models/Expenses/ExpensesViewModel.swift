//
//  SpendingViewModel.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Arpit Bhullar
//

import SwiftUI

// spending view model
class ExpensesViewModel: ObservableObject {
    
    // creates array of type Payment
    @Published var payments: [Payment] = []
    
    // function that contains the results of the query for credit category in transaction collection
    func queryCredit(completion: @escaping (Error?) ->()) {
        PaymentCollection.queryCredit {result in
            switch result {
                case .success(let payments):
                    self.payments = payments
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    
    // function that contains the results of the query for insurance category in transaction collection
    func queryInsuranceDues(completion: @escaping (Error?) ->()) {
        PaymentCollection.queryInsuranceDues { result in
            switch result {
                case .success(let payments):
                    self.payments = payments
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    // function that contains the results of the query for personal category in transaction collection
    func queryOtherBills(completion: @escaping (Error?) ->()) {
        PaymentCollection.queryOtherBills{ result in
            switch result {
                case .success(let payments):
                    self.payments = payments
                    completion(nil)
                case .failure (let err):
                    completion(err)
                
            }
        }
    }
    
    
}
