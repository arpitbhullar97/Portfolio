//
//  AddExpensesView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Arpit Bhullar
//

import SwiftUI
import CoreData
import Firebase

struct AddExpensesView: View {
    
   
    // variable that holds instance of the FireDBHelper class
    @EnvironmentObject var fireDBHelper : FireDBHelper
    
    // variable that holds instance of selected location class
    @EnvironmentObject var selectedLocation : SelectedLocation
    
    // variable to store payment category, initializing it with Credit cards
    @State private var category: String = "CreditCards"
    var categories = ["CreditCards", "Insurance payment", "Other Bills"]
   
    // variable to hold value of selection
    @State private var selection: Int? = nil
    
    // variable to store current cards
    @State private var card: String = "6666 Mastercard"
    var cards = ["6666 Mastercard", "People Store card", "3064 Visa"]
    
    // variable that holds selected date
    @State private var date = Date()
    
    // variable that formats the date
    @State private var dateFormatter = DateFormatter()
    
    // variable that holds amount
    @State private var amount: Int = 0
    
    // variable to hold value of an invalid login
    @State private var invalidTransaction: Bool = false
    
    // variable to hold value of the alert message
    @State private var alertMessage : String = ""
    
    // variable to hold value of alert title
    @State private var alertTitle: String = ""
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
            
        VStack {
            
            // navigation link to expenses view when the selection is 2
            NavigationLink(destination: ExpensesView(), tag: 2, selection: $selection) {}
  
            Form {
                
                // seciton that contains date picker
                Section(header: Text("What date is the payment due?")) {
                    // date picker for user to enter date
                    DatePicker("Select a date: ", selection: $date, displayedComponents: .date)
                }
                .padding(.top, 10)
                
                // secion that contains payment category
                Section(header: Text("Select a category: ")) {
                    Picker(selection: $category, label: Text("Category")) {
                        ForEach (categories, id: \.self) {
                            Text($0)
                        }
                    }
                }
                
                // if the payment due is of related to credit cards, allows user to add to the same category
                if (self.category == "CreditCards") {
                    Section(header: Text("Select from  cards: ")) {
                        Picker (selection: $card, label: Text("Card")) {
                            ForEach (cards, id: \.self) {
                                Text($0)
                            }
                        }
                    }
                }
                
                
                // section that contains amount of payment
                Section(header: Text("How much is the due amount?")) {
                    
                    HStack {
                        
                        Text("$")
                            .font(.system(size: 20))
                        
                        // text field for user to enter amount
                        TextField("Enter amount due:", value: $amount, formatter: NumberFormatter())
                            .padding(10)
                            .keyboardType(.numberPad)
                        
                    } // hstack
                
                }
                
                HStack() {
                    
                    Spacer()
                    
                    // button to add payment
                    Button(action: {
  
                        // checks that all required inputs are filled
                        if (self.validateEmptyData()){
                            
                            // executes if the category selected is credit card
                            if (category == "CreditCards") {

                                // formats the date to a string
                                dateFormatter.dateFormat = "MMM dd YYYY"
                                let formattedDate = dateFormatter.string(from: date)
                                
                                let uid = Auth.auth().currentUser?.uid
                                 // inserts the payment into the firebase database
                                self.fireDBHelper.insertPayment(newPayment: Payment(user: uid!, date: formattedDate, category: self.category, card: self.card, amount: self.amount))
                                
                              
                                
                                // takes user back to expenses view
                                self.presentationMode.wrappedValue.dismiss()
                                
                            }
                            
                            // executes if the category is not credit
                            else if (category != "CreditCards") {
                                
                                //set card to empty string
                                self.card = ""
                                
                                // formats the date into a string
                                dateFormatter.dateFormat = "MMM dd YYYY"
                                let formattedDate = dateFormatter.string(from: date)
                                
                                
                                let uid = Auth.auth().currentUser?.uid

                           // inserts the payment into the firebase database
                                self.fireDBHelper.insertPayment(newPayment: Payment(user: uid!, date: formattedDate, category: self.category, card: self.card, amount: self.amount))
                                
                                
                                // takes user back to expenses view
                                self.presentationMode.wrappedValue.dismiss()
                                
                            }
                            
                        }

                        else {
                               
                            // shows an alert if user did not enter a required field
                            self.alertTitle = "Error"
                            self.alertMessage = "Amount due is required"
                            self.invalidTransaction = true

                        }
                        
                    }, label: {
                       
                        Text("Add")
                            .foregroundColor(Color.black)
                            .font(.body)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .frame(width: 200 , height: 50, alignment: .center)
                    })
                        .background(Color(red: 196/255, green: 234/255, blue: 253/255))
                        .cornerRadius(10)
                        .alert (isPresented: self.$invalidTransaction){
                            // sets text of the alert message and the dismiss button
                            Alert (
                                title: Text(self.alertTitle),
                                message: Text(self.alertMessage),
                                dismissButton: .default(Text("Ok"))
                            )
                        }

                    
                    Spacer()
                    
                } //HStack
                .listRowBackground(Color.clear)
                
            } // form
            
            // gives navigation bar a title
            .navigationBarTitle("Add a payment", displayMode: .inline)
            
        } // VStack
        
    } // body
    
    // function that checks if amount was entered
    private func validateEmptyData() -> Bool{
        if (self.amount == 0){
            return false
        }
        return true
    }

}
struct AddExpensesView_Previews: PreviewProvider {
    static var previews: some View {
        AddExpensesView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
