//
//  ExpensesView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Arpit Bhullar 
//

import Foundation
import SwiftUI

// view that shows all payments
struct ExpensesView: View {
    
    // variable that holds instance of the FireDBHelper class
    @EnvironmentObject var fireDBHelper : FireDBHelper
    
    // variable to hold value of selection
    @State private var selection: Int? = nil

    @EnvironmentObject var loginViewModel : LoginManager
    
    // variable that holds instance of Expenses view model class
    @StateObject private var viewModel = ExpensesViewModel()
    
    // variable that holds the total amount from the insurance category
    @State private var totalInsurance : Int = 0
    
    // variable that holds the total amount from the credit category
    @State private var totalCredit : Int = 0
    
    // variable that holds the total amount from the other bills category
    @State private var totalOthers : Int = 0
    
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
                
            HStack {
                    
                // creates navigation link to login view when the logout button is clicked
                    Button(action: {

                        loginViewModel.isLoggedIn = false
                    }, label: {
                        Text("Log Out")
                    })
                //}
                .padding(.leading, 20)
                
                Spacer()
                    
                // adds the logo image to top of view
                Image("cents")
                    .resizable()
                    .frame(width: 90, height: 20)
                    .offset(x: -15)
                
                Spacer()
                    
                // creates navigation link to add expenses view when the add button is clicked
                NavigationLink(destination: AddExpensesView(), tag: 2, selection: $selection) {
                    Button(action: {
                        self.selection = 2
                    }, label: {
                        Text("Add")
                    })
                }
                .padding(.trailing, 20)
                
            } // hstack
            
            List {
                
                // navigation link to credit view
                NavigationLink(destination: CreditCardsView(), tag: 3, selection: $selection) {
                    
                    // displays credit text and total amount of credit
                    HStack {
                        Text ("Credit Card Bills")
                        Spacer()
                        Text ("$ \(self.totalCredit)")
                    }
                }
                
            
                NavigationLink(destination: OtherBillsView(), tag: 4, selection: $selection) {
                    
                  
                    HStack {
                        Text ("Other Bills")
                        Spacer()
                        Text ("$ \(self.totalOthers)")
                    }
                }
                
                
                // navigation link to insurance view
                NavigationLink(destination: InsuranceDueView(), tag: 5, selection: $selection) {
                    
                    // displays insurance text and total amount of insurance
                    HStack {
                        Text ("Insurance Dues")
                        Spacer()
                        Text ("$ \(self.totalInsurance)")
                    }
                }

            
        
            }
        }.onAppear(perform: {
                    
                    // calls the queryCredit method from view model
                    viewModel.queryCredit { err in
                        if let err = err {
                            print(err.localizedDescription)
                            return
                        }
                        print(viewModel.payments)
                        
                        // adds credit total
                        addCreditTotal(total: viewModel.payments)
                    }
             //calls the queryOtherBills method from view model
                    viewModel.queryOtherBills{ err in
                        if let err = err {
                            print(err.localizedDescription)
                            return
                        }
                        print(viewModel.payments)
                        
                        // adds Other Bills total
                        addOtherBillsTotal(total: viewModel.payments)
                    }
                    
                    // calls the queryInsurance method from view model
                    viewModel.queryInsuranceDues { err in
                        if let err = err {
                            print(err.localizedDescription)
                            return
                        }
                        print(viewModel.payments)
                        
                        // adds insurance total
                        addInsuranceTotal(total: viewModel.payments)
                    }
        })
            
            // when view disappears, sets all category totals to 0 to prevent them from multiplying
            .onDisappear(perform: {
                self.totalCredit = 0
                self.totalOthers = 0
                self.totalInsurance = 0
              
            })
    }
        // function that adds the Credit total
        private func addCreditTotal(total: [Payment]) {
            for payment in total {
                self.totalCredit += payment.amount
            }
        }
        
        // function that adds the insurance total
        private func addInsuranceTotal(total: [Payment]) {
            for payment in total {
                self.totalInsurance += payment.amount
            }
        }
        
        // function that adds the Other Bills total
        private func addOtherBillsTotal(total: [Payment]) {
            for payment in total {
                self.totalOthers += payment.amount
            }
        }
        
} // view

struct ExpensesView_Previews: PreviewProvider {
    static var previews: some View {
        ExpensesView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
