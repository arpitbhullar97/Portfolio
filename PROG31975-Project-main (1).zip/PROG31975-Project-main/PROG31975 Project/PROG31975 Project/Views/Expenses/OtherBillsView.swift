//
//  OtherBillsView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Arpit Bhullar
//

import Foundation
import SwiftUI

// Other Bills view that shows all payments in other bills category
struct OtherBillsView: View {
    
    // variable that holds instance of Expenses view model class
    @StateObject private var viewModel = ExpensesViewModel()

    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {

            // for each payment where category = Other Bills
            ForEach (viewModel.payments.map({$0}), id: \.id) {payment in
                
                VStack {
                    
                    // displays the payment date
                    Text(payment.date)
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack {
                        
                        // displays the payment category
                        Text(payment.category)
                        
                        Spacer()
                        
                        // displays the payment amount
                        Text("$ \(String(payment.amount))")
                        
                    } // hstack
                    
                } // vstack

            } // foreach
            
        } // list
        
        .onAppear(perform: {
            viewModel.queryOtherBills { err in
                if let err = err {
                    print(err.localizedDescription)
                    return
                }
                print(viewModel.payments)
            }
        }) // on appear
        
        .navigationBarTitle("Other Bills", displayMode: .inline)

    } // body
        
} // view

struct OtherBillsView_Previews: PreviewProvider {
    static var previews: some View {
        OtherBillsView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
