//
//  LocationListVIew.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI
import MapKit

// struct that contains the location list view
struct LocationListView: View {
    
    // array of type landmark
    let landmarks: [Landmark]
    var onTap: () -> ()
    
    // handles the users selection from the list
    @State private var selection: Int? = nil
    
    // creates instance of selected location class
    @EnvironmentObject var selectedLocation : SelectedLocation
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        VStack(alignment: .leading) {
            
            List {
                
                // iterates through landmark list and adds the location name and title to the list
                ForEach(self.landmarks, id: \.id) {
                    landmark in
                    
                    VStack(alignment: .leading) {
                        
                        Text(landmark.name)
                            .fontWeight(.bold)
                        
                        Text(landmark.title)
                        
                    } // vstack
                    
                    // when user taps on a location in the list, it adds the name and title to the selected location class
                    .onTapGesture {
                        selectedLocation.name = landmark.name
                        selectedLocation.title = landmark.title
                        print(selectedLocation.name, selectedLocation.title)
                        self.presentationMode.wrappedValue.dismiss()
                    }
                    
                } // foreach
                
            } // list
            
            .animation(.none, value: UUID())
            .gesture(TapGesture()
                .onEnded(self.onTap)
            )
            .cornerRadius(20)
            
        } // vstack
        
        .cornerRadius(10)
        
    } // body
    
} // view

struct LocationListView_Previews: PreviewProvider {
    static var previews: some View {
        LocationListView(landmarks: [Landmark(placemark: MKPlacemark())], onTap: {})
    }
}
