//
//  MapView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import SwiftUI
import MapKit

// class that handles the coordination of the map view
class Coordinator: NSObject, MKMapViewDelegate, UIGestureRecognizerDelegate {
    
    var control: MapView
    
    // variable that stores instance of UITapGestureRecognizer
    var gRecognizer = UITapGestureRecognizer()
    
    // initializes the recognizer and gestures
    init(_ control: MapView) {
        self.control = control
        super.init()
        self.gRecognizer = UITapGestureRecognizer(target: self, action: #selector(Coordinator.tapHandler(gesture:)))
        self.gRecognizer.delegate = self
        self.control.mapView.addGestureRecognizer(gRecognizer)
    }
    
    // function that handles when user taps on the map view
    @objc func tapHandler(gesture: UITapGestureRecognizer) {
        // position on the screen, CGPoint
        let location = gRecognizer.location(in: self.control.mapView)
        // position on the map, CLLocationCoordinate2D
        let coordinate = self.control.mapView.convert(location, toCoordinateFrom: self.control.mapView)
        print(coordinate.latitude)
            
    }
    
    // function that annotates the map and sets the region
    func mapView(_ mapView: MKMapView, didAdd views: [MKAnnotationView]) {
        if let annotationView = views.first {
            if let annotation = annotationView.annotation {
                if annotation is MKUserLocation {
                    
                    let region = MKCoordinateRegion(center: annotation.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
                    mapView.setRegion(region, animated: true)
                    
                }
            }
        }
    }

}

// struct that handles map view
struct MapView: UIViewRepresentable {
    
    // instance of MKMapView
    let mapView = MKMapView()
    
    // generates array of type landmark
    let landmarks: [Landmark]
    
    // function that shows users location on map
    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.showsUserLocation = true
        map.delegate = context.coordinator
        return map
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    // function that updates the UI
    func updateUIView(_ uiView: MKMapView, context: UIViewRepresentableContext<MapView>) {
        
        updateAnnotations(from: uiView)
        
    }
    
    // function that adds annotations 
    private func updateAnnotations(from mapView: MKMapView) {
            mapView.removeAnnotations(mapView.annotations)
            let annotations = self.landmarks.map(LandmarkAnnotation.init)
            mapView.addAnnotations(annotations)
    }
    
}
