//
//  LocationView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI
import CoreData
import MapKit

// location view that shows the map and the landmark list
struct LocationView: View {
    
    // creates an instance of the location helper class
    @ObservedObject var locationHelper = LocationHelper()
    
    // creates an array of type landmark
    @State private var landmarks: [Landmark] = [Landmark]()
    
    @State private var tapped: Bool = false
    
    // variable that stores users search
    @State private var search: String = ""
    
    // function that gets landmarks near the user
    private func getNearByLandmarks() {
        
        // uses natural language to query the nearby landmarks using MKLocalSearch
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = search
        
        // takes the users search and maps them on the map
        let search = MKLocalSearch(request: request)
        search.start { (response, error) in
            if let response = response {
                
                let mapItems = response.mapItems
                self.landmarks = mapItems.map {
                    Landmark(placemark: $0.placemark)
                }
                
            }
            
            // for each landmark on the map, it prints the name and location to the console
            for item in response!.mapItems {
                if let name = item.name,
                   let location = item.placemark.location {
                    print("\(name): \(location.coordinate.latitude), \(location.coordinate.longitude)")
                }
            }
        }
        
    }
    
    // function that calculates the offset and dimensions of the landmark list
    func calculateOffset() -> CGFloat {
        
        // sets teh height of the list if the landmark list is not empty
        if self.landmarks.count > 0 && !self.tapped {
            
            return UIScreen.main.bounds.size.height - UIScreen.main.bounds.size.height / 4
        }
        
        // if the list is tapped, returns 100 as the offset
        else if self.tapped {
            return 100
        }
        
        // if the list is empty, no list view shows
        else {
            return UIScreen.main.bounds.size.height
        }
        
    }
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        ZStack (alignment: .top) {
            
            // calls the mapview class that displays the landmarks
            MapView(landmarks: landmarks)
            
            // textfield that will take in the users search query
            TextField("Search", text: $search, onEditingChanged: { _ in})
            {
                // gets nearby landmarks
                self.getNearByLandmarks()
                
            }.textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .offset(y: 44)
            
            // calls the location list view class
            LocationListView(landmarks: self.landmarks) {
                self.tapped.toggle()
            }
            
            // creates the animation for the list when tapped
            .animation(Animation.interpolatingSpring(mass: 1, stiffness: 100, damping: 30, initialVelocity: 4))
            .offset(y: calculateOffset())
            
        }
        
    }
}

struct LocationView_Previews: PreviewProvider {
    static var previews: some View {
        LocationView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}


