//
//  TransportationView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import SwiftUI

// food view that shows all transactions in transportation category
struct TransportationView: View {
    
    // variable that holds instance of spending view model class
    @StateObject private var viewModel = SpendingViewModel()
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {
            
            // for each transaction where category = transportation
            ForEach (viewModel.transactions, id: \.id) { transaction in
                
                VStack {
                    
                    // displays the transaction date
                    Text(transaction.date)
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack {
                        
                        // displays the transaction location
                        Text(transaction.location)
                        
                        Spacer()
                        
                        // displays the transaction cost
                        Text("$ \(String(transaction.cost))")
                        
                    } // hstack
                    
                } // vstack
                
            } // foreach
            
        } // list
        
        // when view appears, executes queryTransportation in the view model
        .onAppear(perform: {
            viewModel.queryTransportation { err in
                if let err = err {
                    print(err.localizedDescription)
                    return
                }
                print(viewModel.transactions)
            }
        }) // on appear
        
        .navigationBarTitle("Transportation", displayMode: .inline)

    } // body
        
} // view

struct TransportationView_Previews: PreviewProvider {
    static var previews: some View {
        TransportationView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
