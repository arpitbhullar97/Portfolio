//
//  HousingView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import SwiftUI

// housing view that shows all transactions in housing category
struct HousingView: View {
    
    // variable that holds instance of spending view model class
    @StateObject private var viewModel = SpendingViewModel()
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {
            
            // for each transaction where category = housing
            ForEach (viewModel.transactions, id: \.id) { transaction in
                
                VStack {
                    
                    // displays the transaction date
                    Text(transaction.date)
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack {
                        
                        // displays the transaction location
                        Text(transaction.location)
                        
                        Spacer()
                        
                        // displays the transaction cost
                        Text("$ \(String(transaction.cost))")
                        
                    } // hstack
                    
                } // vstack
                
            } // foreach
            
        } // list
        
        // when view appears, executes queryHousing in the view model
        .onAppear(perform: {
            viewModel.queryHousing { err in
                if let err = err {
                    print(err.localizedDescription)
                    return
                }
                print(viewModel.transactions)
            }
        }) // on appear
        
        .navigationBarTitle("Housing", displayMode: .inline)

    } // body
        
} // view

struct HousingView_Previews: PreviewProvider {
    static var previews: some View {
        HousingView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
