//
//  AddSpendingView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI
import CoreData
import Firebase

struct AddSpendingView: View {
    
    // variable that holds instance of selected location class
    @EnvironmentObject var selectedLocation : SelectedLocation
    
    // variable that holds instance of the FireDBHelper class
    @EnvironmentObject var fireDBHelper : FireDBHelper
    
    // variable to hold value of selection
    @State private var selection: Int? = nil
    
    // variable to hold value of if the link is tapped or not
    @State private var isTapped: Bool = false
    
    // variable to show map as sheet
    @State private var showSheet = false
    
    // variable that holds selected date
    @State private var date = Date()
    
    // variable that formats the date
    @State private var dateFormatter = DateFormatter()
    
    // variable that holds cost
    @State private var cost: Int = 0
    
    // variable to store transaction category, initializing it with food
    @State private var category: String = "Food"
    var categories = ["Food", "Housing", "Transportation", "Insurance", "Personal", "Budget"]
    
    // variable to store current budgets
    @State private var budget: String = "2021 Vacation"
    var budgets = ["2021 Vacation", "2021 Christmas", "Dream Wedding"]
    
    // variable to hold value of the alert message
    @State private var alertMessage : String = ""
    
    // variable to hold value of alert title
    @State private var alertTitle: String = ""
    
    // variable to hold value of an invalid login
    @State private var invalidTransaction: Bool = false
    
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
            
        VStack {
            
            // navigation link to spending view when the selection is 2
            NavigationLink(destination: SpendingView(), tag: 2, selection: $selection) {}
  
            Form {
                
                // seciton that contains date picker
                Section(header: Text("What date did the transaction occur?")) {
                    // date picker for user to enter date
                    DatePicker("Select a date: ", selection: $date, displayedComponents: .date)
                }
                .padding(.top, 10)
                
                // secion that contains transaction category
                Section(header: Text("Select a category: ")) {
                    Picker(selection: $category, label: Text("Category")) {
                        ForEach (categories, id: \.self) {
                            Text($0)
                        }
                    }
                }
                
                // if the transaction is allocated to "budget", allows user to select from current budgets
                if (self.category == "Budget") {
                    Section(header: Text("Select from  budgets: ")) {
                        Picker (selection: $budget, label: Text("Budget")) {
                            ForEach (budgets, id: \.self) {
                                Text($0)
                            }
                        }
                    }
                }
                
                // section that contains cost of transaction
                Section(header: Text("How much was spent or saved?")) {
                    
                    HStack {
                        
                        Text("$")
                            .font(.system(size: 20))
                        
                        // text field for user to enter cost
                        TextField("Enter cost", value: $cost, formatter: NumberFormatter())
                            .padding(10)
                            .keyboardType(.numberPad)
                        
                    } // hstack
                
                }
                
                // section that contains location
                Section(header: Text("Select a location (optional):")) {
                    
                    VStack {
                        
                        // provides link to location view
                        HStack {

                            // creates navigation link to location view
                            NavigationLink(destination: LocationView(), tag: 1, selection: $selection) {}

                        } // HStack
                        // navigate to location view on tap
                        .onTapGesture {
                            self.selection = 1
                        }
                        
                        // displays the selected location name and title
                        if (self.selectedLocation.title != "") {
                            
                            Text("\(self.selectedLocation.name), \(self.selectedLocation.title)")
                            
                        }
                        
                    } // vstack
                }
                
                HStack() {
                    
                    Spacer()
                    
                    // button to add transaction
                    Button(action: {
  
                        // checks that all required inputs are filled
                        if (self.validateEmptyData()){
                            
                            // executes if the category selected is budget
                            if (category == "Budget") {

                                // formats the date to a string
                                dateFormatter.dateFormat = "MMM dd YYYY"
                                let formattedDate = dateFormatter.string(from: date)
                                
                                let uid = Auth.auth().currentUser?.uid

                                // inserts the transaction into the firebase database
                                self.fireDBHelper.insertTransaction(newTransaction: Transaction(user: uid!, date: formattedDate, category: self.category, budget: self.budget, cost: self.cost, location:  self.selectedLocation.name))
                                
                                // set the location name and title to empty strings once added to firebase
                                selectedLocation.name = ""
                                selectedLocation.title = ""
                                
                                // takes user back to spending view
                                self.presentationMode.wrappedValue.dismiss()
                                
                            }
                            
                            // executes if the category is not budget
                            else if (category != "Budget") {
                                
                                // sets budget to an empty string
                                self.budget = "";
                                
                                // formats the date into a string
                                dateFormatter.dateFormat = "MMM dd YYYY"
                                let formattedDate = dateFormatter.string(from: date)
                                
                                
                                let uid = Auth.auth().currentUser?.uid

                                // inserts the transaction into the firebase database
                                self.fireDBHelper.insertTransaction(newTransaction: Transaction(user: uid!, date: formattedDate, category: self.category, budget: self.budget, cost: self.cost, location:  self.selectedLocation.name))
                                
                                // set the location name and title to empty strings once added to firebase
                                selectedLocation.name = ""
                                selectedLocation.title = ""
                                
                                // takes user back to spending view
                                self.presentationMode.wrappedValue.dismiss()
                                
                            }
                            
                        }

                        else {
                               
                            // shows an alert if user did not enter a required field
                            self.alertTitle = "Error"
                            self.alertMessage = "Cost of transaction is required"
                            self.invalidTransaction = true

                        }
                        
                    }, label: {
                       
                        Text("Add")
                            .foregroundColor(Color.black)
                            .font(.body)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .frame(width: 200 , height: 50, alignment: .center)
                    })
                        .background(Color(red: 196/255, green: 234/255, blue: 253/255))
                        .cornerRadius(10)
                        .alert (isPresented: self.$invalidTransaction){
                            // sets text of the alert message and the dismiss button
                            Alert (
                                title: Text(self.alertTitle),
                                message: Text(self.alertMessage),
                                dismissButton: .default(Text("Ok"))
                            )
                        }

                    
                    Spacer()
                    
                } //HStack
                .listRowBackground(Color.clear)
                
            } // form
            
            // gives navigation bar a title
            .navigationBarTitle("Add a transaction", displayMode: .inline)
            
        } // VStack
        
    } // body
    
    // function that checks if cost was entered
    private func validateEmptyData() -> Bool{
        if (self.cost == 0){
            return false
        }
        return true
    }

}

struct AddSpendingView_Previews: PreviewProvider {
    static var previews: some View {
        AddSpendingView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
