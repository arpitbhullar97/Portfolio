//
//  BudgetView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import SwiftUI

// food view that shows all transactions in budget category
struct BudgetView: View {
    
    // variable that holds instance of spending view model class
    @StateObject private var viewModel = SpendingViewModel()
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {
            
            // for each transaction where category = budget
            ForEach (viewModel.transactions, id: \.id) { transaction in
                
                VStack {
                    
                    HStack {
                        
                        // displays the transaction date
                        Text(transaction.date)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Spacer()
                        
                        // displays the transaction budget
                        Text(transaction.budget)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                        
                    } // hstack
                    
                    HStack {
                        
                        // displays the transaction location
                        Text(transaction.location)
                        
                        Spacer()
                        
                        // displays the transaction cost
                        Text("$ \(String(transaction.cost))")
                        
                    } // hstack
                    
                } // vstack
                
            } // foreach
            
        } // list
        
        // when view appears, executes queryBudget in the view model
        .onAppear(perform: {
            viewModel.queryBudget { err in
                if let err = err {
                    print(err.localizedDescription)
                    return
                }
                print(viewModel.transactions)
            }
        }) // on appear
        
        .navigationBarTitle("Budget", displayMode: .inline)

    } // body
        
} // view

struct BudgetView_Previews: PreviewProvider {
    static var previews: some View {
        BudgetView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
