//
//  CategoryView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//
import Foundation
import SwiftUI

// food view that shows all transactions in food category
struct FoodView: View {
    
    // variable that holds instance of spending view model class
    @StateObject private var viewModel = SpendingViewModel()

    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {

            // for each transaction where category = food
            ForEach (viewModel.transactions.map({$0}), id: \.id) {transaction in
                
                VStack {
                    
                    // displays the transaction date
                    Text(transaction.date)
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack {
                        
                        // displays the transaction location
                        Text(transaction.location)
                        
                        Spacer()
                        
                        // displays the transaction cost
                        Text("$ \(String(transaction.cost))")
                        
                    } // hstack
                    
                } // vstack

            } // foreach
            
        } // list
        
        // when view appears, executes queryFood in the view model
        .onAppear(perform: {
            viewModel.queryFood { err in
                if let err = err {
                    print(err.localizedDescription)
                    return
                }
                print(viewModel.transactions)
            }
        }) // on appear
        
        .navigationBarTitle("Food", displayMode: .inline)

    } // body
        
} // view

struct FoodView_Previews: PreviewProvider {
    static var previews: some View {
        FoodView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
