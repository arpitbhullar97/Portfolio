//
//  SpendingView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI
import CoreData
import Firebase

// enum that contains each of the categories
enum Asset {
    case Food, Housing, Personal, Insurance, Transportation, Budget
}

// struct that contains the properties for each slice of the pie chart
struct CategoryAllocation {
    let asset: Asset
    let percentage: Double
    let description: String
    let color: Color
}

// creates the shape of the pie chart
struct PieceOfPie: Shape {
    let startDegree: Double
    let endDegree: Double
    
    func path (in rect: CGRect) -> Path {
        Path { p in
            let center = CGPoint(x: rect.midX, y: rect.midY)
            p.move(to: center)
            p.addArc(
                center: center,
                radius: rect.width / 2,
                startAngle: Angle(degrees: startDegree),
                endAngle: Angle(degrees: endDegree),
                clockwise: false
            )
            p.closeSubpath()
        }
    }
}

// struct that manages the spending view
struct SpendingView: View {
    
    var model = WatchOSController()
    
    @EnvironmentObject var loginViewModel : LoginManager
    
    // creates instance of the FireDBHelper class
    @EnvironmentObject var fireDBHelper : FireDBHelper
    
    // variable to hold value of selection
    @State private var selection: Int? = nil

    // variable that holds the total cost from the food category
    @State private var totalFood : Int = 0
    
    // variable that holds the total cost from the housing category
    @State private var totalHousing : Int = 0
    
    // variable that holds the total cost from the transportation category
    @State private var totalTransportation : Int = 0
    
    // variable that holds the total cost from the insurance category
    @State private var totalInsurance : Int = 0
    
    // variable that holds the total cost from the personal category
    @State private var totalPersonal : Int = 0
    
    // variable that holds the total cost from the budget category
    @State private var totalBudget : Int = 0
    
    // variable that holds the total cost for the user
    @State private var totalSpending : Int = 0
    
    // creates instance of the spending view model
    @StateObject private var viewModel = SpendingViewModel()
    
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
            
        VStack {
                
            HStack {
                    
                // creates navigation link to login view when the logout button is clicked
                    Button(action: {

                        loginViewModel.isLoggedIn = false
                    }, label: {
                        Text("Log Out")
                    })
                //}
                .padding(.leading, 20)
                
                Spacer()
                    
                // adds the logo image to top of view
                Image("cents")
                    .resizable()
                    .frame(width: 90, height: 20)
                    .offset(x: -15)
                
                Spacer()
                    
                // creates navigation link to add spending view when the add button is clicked
                NavigationLink(destination: AddSpendingView(), tag: 2, selection: $selection) {
                    Button(action: {
                        self.selection = 2
                    }, label: {
                        Text("Add")
                    })
                }
                .padding(.trailing, 20)
                
            } // hstack
            
            .offset(y: 17)
            .padding(.bottom, 30)
            
            // variable that holds the total cost of all categories
            let total: Double = Double(self.totalFood + self.totalBudget + self.totalHousing + self.totalPersonal + self.totalInsurance + self.totalTransportation)

            // array that stores the percentage and colour of each slice on the pie chart
            let data: [CategoryAllocation] = [
                
                // generates the food slice
                CategoryAllocation(asset: .Food, percentage: Double(self.totalFood) / total, description: "Food", color: Color(red: 241/255, green: 250/255, blue: 238/255)),
                
                // generates the housing slice
                CategoryAllocation(asset: .Housing, percentage: Double(self.totalHousing) / total, description: "Housing", color: Color(red: 205/255, green: 234/255, blue: 229/255)),
                
                // generates the budget slice
                CategoryAllocation(asset: .Budget, percentage: Double(self.totalBudget) / total, description: "Budget", color: Color(red: 168/255, green: 218/255, blue: 220/255)),
                
                // generates the personal slice
                CategoryAllocation(asset: .Personal, percentage: Double(self.totalPersonal) / total, description: "Personal", color: Color(red: 119/255, green: 171/255, blue: 189/255)),
                
                // generates the insurance slice
                CategoryAllocation(asset: .Insurance, percentage: Double(self.totalInsurance) / total, description: "Insurance", color: Color(red: 69/255, green: 123/255, blue: 157/255)),
                
                // generates the transportation slice
                CategoryAllocation(asset: .Transportation, percentage: Double(self.totalTransportation) / total, description: "Transportation", color: Color(red: 29/255, green: 53/255, blue: 87/255)),
            ]
            
            ZStack {
                
                // for each item in the above array, generates the current data, current end degree, and last degree to generate the pie chart
                ForEach (0..<data.count) { index in
                    let currentData = data[index]
                    let currentEndDegree = currentData.percentage * 360
                    let lastDegree = data.prefix(index).map{$0.percentage}.reduce(0, +) * 360
                        
                    ZStack {
                        PieceOfPie(startDegree: lastDegree, endDegree: lastDegree + currentEndDegree)
                            .fill(currentData.color)
            
                    }
                }
            }
            .frame(width: 250, height: 250, alignment: .center)
            .padding(.bottom)
            
            // displays the legend for the pie chart
            HStack {
                VStack {
                    HStack {
                        // creates square with colour pertaining to colour on chart
                        Rectangle()
                            .fill(Color(red: 241/255, green: 250/255, blue: 238/255))
                            .frame(width: 16, height: 16, alignment: .center)
                            .border(Color.gray)
                        
                        // creates the text and percentage for food in the legend
                        Text("Food (\(((Double(self.totalFood) / total) * 100), specifier: "%.2f")%)")
                            .font(.system(size: 14))
                    }
                    HStack {
                        // creates square with colour pertaining to colour on chart
                        Rectangle()
                            .fill(Color(red: 205/255, green: 234/255, blue: 229/255))
                            .frame(width: 16, height: 16, alignment: .center)
                            .border(Color.gray)
                        
                        // creates the text and percentage for housing in the legend
                        Text("Housing (\(((Double(self.totalHousing) / total) * 100), specifier: "%.2f")%)")
                            .font(.system(size: 14))
                    }
                    HStack {
                        // creates square with colour pertaining to colour on chart
                        Rectangle()
                            .fill(Color(red: 69/255, green: 123/255, blue: 157/255))
                            .frame(width: 16, height: 16, alignment: .center)
                            .border(Color.gray)
                        
                        // creates the text and percentage for insurance in the legend
                        Text("Insurance (\(((Double(self.totalInsurance) / total) * 100), specifier: "%.2f")%)")
                            .font(.system(size: 14))
                    }
                
                } // vstack
                
                VStack {
                    HStack {
                        // creates square with colour pertaining to colour on chart
                        Rectangle()
                            .fill(Color(red: 29/255, green: 53/255, blue: 87/255))
                            .frame(width: 16, height: 16, alignment: .center)
                            .border(Color.gray)
                        
                        // creates the text and percentage for transportation in the legend
                        Text("Transportation (\(((Double(self.totalTransportation) / total) * 100), specifier: "%.2f")%)")
                            .font(.system(size: 14))
                    }
                    HStack {
                        // creates square with colour pertaining to colour on chart
                        Rectangle()
                            .fill(Color(red: 119/255, green: 171/255, blue: 189/255))
                            .frame(width: 16, height: 16, alignment: .center)
                            .border(Color.gray)
                        
                        // creates the text and percentage for personal in the legend
                        Text("Personal (\(((Double(self.totalPersonal) / total) * 100), specifier: "%.2f")%)")
                            .font(.system(size: 14))
                    }
                    HStack {
                        // creates square with colour pertaining to colour on chart
                        Rectangle()
                            .fill(Color(red: 168/255, green: 218/255, blue: 220/255))
                            .frame(width: 16, height: 16, alignment: .center)
                            .border(Color.gray)
                        
                        // creates the text and percentage for budget in the legend
                        Text("Budget (\(((Double(self.totalBudget) / total) * 100), specifier: "%.2f")%)")
                            .font(.system(size: 14))
                    }
                   
                } // vstack
                
            } // hstack
            // creates a list of each category
            List {
                
                // navigation link to food view
                NavigationLink(destination: FoodView(), tag: 3, selection: $selection) {
                    
                    // displays food text and total cost of food
                    HStack {
                        Text ("Food")
                        Spacer()
                        Text ("$ \(self.totalFood)")
                    }
                }
                
                // navigation link to housing view
                NavigationLink(destination: HousingView(), tag: 4, selection: $selection) {
                    
                    // displays housing text and total cost of housing
                    HStack {
                        Text ("Housing")
                        Spacer()
                        Text ("$ \(self.totalHousing)")
                    }
                }
                
                // navigation link to transportation view
                NavigationLink(destination: TransportationView(), tag: 5, selection: $selection) {
                    
                    // displays transportation text and total cost of transportation
                    HStack {
                        Text ("Transportation")
                        Spacer()
                        Text ("$ \(self.totalTransportation)")
                    }
                }
                
                // navigation link to insurance view
                NavigationLink(destination: InsuranceView(), tag: 6, selection: $selection) {
                    
                    // displays insurance text and total cost of insurance
                    HStack {
                        Text ("Insurance")
                        Spacer()
                        Text ("$ \(self.totalInsurance)")
                    }
                }

                // navigation link to personal view
                NavigationLink(destination: PersonalView(), tag: 7, selection: $selection) {
                    
                    // displays personal text and total cost of personal
                    HStack {
                        Text ("Personal")
                        Spacer()
                        Text ("$ \(self.totalPersonal)")
                    }
                }
                
                // navigation link to budget view
                NavigationLink(destination: BudgetView(), tag: 8, selection: $selection) {
                    
                    // displays budget text and total cost of budget
                    HStack {
                        Text ("Budget")
                        Spacer()
                        Text ("$ \(self.totalBudget)")
                    }
                }

            } // list
            
            .onAppear(perform: {
                
                // calls the queryFood method from view model
                viewModel.queryFood { err in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    print(viewModel.transactions)
                    
                    // adds food total
                    addFoodTotal(total: viewModel.transactions)
                }
                
                // calls the queryHousing method from view model
                viewModel.queryHousing { err in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    print(viewModel.transactions)
                    
                    // adds housing total
                    addHousingTotal(total: viewModel.transactions)
                }
                
                // calls the queryTransportation method from view model
                viewModel.queryTransportation { err in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    print(viewModel.transactions)
                    
                    // adds transportation total
                    addTransportationTotal(total: viewModel.transactions)
                }
                
                // calls the queryInsurance method from view model
                viewModel.queryInsurance { err in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    print(viewModel.transactions)
                    
                    // adds insurance total
                    addInsuranceTotal(total: viewModel.transactions)
                }
                
                // calls the queryPersonal method from view model
                viewModel.queryPersonal { err in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    print(viewModel.transactions)
                    
                    // adds personal total
                    addPersonalTotal(total: viewModel.transactions)
                }
                
                // calls the queryBudget method from view model
                viewModel.queryBudget { err in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    print(viewModel.transactions)
                    
                    // adds budget total
                    addBudgetTotal(total: viewModel.transactions)
                }
                
                // calls the queryTotal method from the view model
                viewModel.queryTotal { err in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    print(viewModel.transactions)
  
                    getTotal(total: viewModel.transactions)
                }

            })
            
            // when view disappears, sets all category totals to 0 to prevent them from multiplying
            .onDisappear(perform: {
                self.totalFood = 0
                self.totalHousing = 0
                self.totalTransportation = 0
                self.totalInsurance = 0
                self.totalPersonal = 0
                self.totalBudget = 0
                self.totalSpending = 0
            })
                
        } // vstack
    } // body
    
    // function that adds the food total
    private func addFoodTotal(total: [Transaction]) {
        for transaction in total {
            self.totalFood += transaction.cost
            
            self.totalSpending += self.totalFood
            
        }
    }
    
    // function that adds the housing total
    private func addHousingTotal(total: [Transaction]) {
        for transaction in total {
            self.totalHousing += transaction.cost
            
            self.totalSpending += self.totalHousing

        }
            
    }
    
    // function that adds the transportation total
    private func addTransportationTotal(total: [Transaction]) {
        for transaction in total {
            self.totalTransportation += transaction.cost
            
            self.totalSpending += self.totalTransportation
        }
    }
    
    // function that adds the insurance total
    private func addInsuranceTotal(total: [Transaction]) {
        for transaction in total {
            self.totalInsurance += transaction.cost
            
            self.totalSpending += self.totalInsurance
        }
    }
    
    // function that adds the personal total
    private func addPersonalTotal(total: [Transaction]) {
        for transaction in total {
            self.totalPersonal += transaction.cost
            
            self.totalSpending += self.totalPersonal
        }
    }
    
    // function that adds the budget total
    private func addBudgetTotal(total: [Transaction]) {
        for transaction in total {
            self.totalBudget += transaction.cost
            
            self.totalSpending += self.totalBudget
        }
    }
    
    // function that adds the total cost for the user
    private func getTotal(total: [Transaction]) {
        for transaction in total {
            self.totalSpending += transaction.cost
            
            self.model.session.sendMessage(["message" : self.totalSpending], replyHandler: nil) { (error) in
                    print(error.localizedDescription)
            }
        }
    }

}

struct SpendingView_Previews: PreviewProvider {
    static var previews: some View {
        SpendingView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
