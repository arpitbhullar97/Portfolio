//
//  PersonalView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import Foundation
import SwiftUI

// food view that shows all transactions in personal category
struct PersonalView: View {
    
    // variable that holds instance of spending view model class
    @StateObject private var viewModel = SpendingViewModel()
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {
            
            // for each transaction where category = personal
            ForEach (viewModel.transactions, id: \.id) { transaction in
                
                VStack {
                    
                    // displays the transaction date
                    Text(transaction.date)
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack {
                        
                        // displays the transaction location
                        Text(transaction.location)
                        
                        Spacer()
                        
                        // displays the transaction cost
                        Text("$ \(String(transaction.cost))")
                        
                    } // hstack
                    
                } // vstack
                
            } // foreach
            
        } // list
        
        // when view appears, executes queryPersonal in the view model
        .onAppear(perform: {
            viewModel.queryPersonal { err in
                if let err = err {
                    print(err.localizedDescription)
                    return
                }
                print(viewModel.transactions)
            }
        }) // on appear
        
        .navigationBarTitle("Personal", displayMode: .inline)

    } // body
        
} // view

struct PersonalView_Previews: PreviewProvider {
    static var previews: some View {
        PersonalView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
