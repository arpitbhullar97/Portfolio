//
//  SignUpView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI
import CoreData
import Firebase

// sign up view
struct SignUpView: View {
    
    @EnvironmentObject var viewModel : LoginManager
    
    // variable to store first name entered by user
    @State private var firstName: String = ""
    
    // variable to store last name entered by user
    @State private var lastName: String = ""
    
    // variable to store username entered by user
    @State private var email: String = ""
    
    // variable to store password entered by user
    @State private var password: String  = ""
    
    // variable to hold value of the alert message
    @State private var alertMessage : String = ""
    
    // variable to hold value of alert title
    @State private var alertTitle: String = ""
    
    // variable to hold value of an invalid login
    @State private var invalidSignUp: Bool = false
    
    // variable to hold value of if the sign up link is tapped or not
    @State private var isLoginTapped: Bool = false
    
    // variable to hold value of selection
    @State private var selection: Int? = nil
    
    // variable that holds value of login status
    @State var loginStatusMessage = ""
    
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
            
            VStack {
                
                // creates navigation link to spending view
                NavigationLink(destination: LoginView().navigationBarHidden(true), tag: 1, selection: $selection) {}
                
                // adds the logo image to top of view
                Image("cents logo")
                    .resizable()
                    .frame(width: 150, height: 150)
                    .padding(.bottom, 60)
                    .offset(y: -35)
                
                // sign up text
                Text("Sign Up")
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 40)
                    .font(.system(size: 35))
                    .offset(y: -80)
                
                //textfield for user to enter first name
                TextField("Enter first name", text: $firstName)
                    .padding(.leading, 40)
                    .padding(.trailing, 40)
                    .padding(.bottom, 25)
                    .textFieldStyle(.roundedBorder)
                    .offset(y: -70)
                
                //textfield for user to enter last name
                TextField("Enter last name", text: $lastName)
                    .padding(.leading, 40)
                    .padding(.trailing, 40)
                    .padding(.bottom, 25)
                    .textFieldStyle(.roundedBorder)
                    .offset(y: -60)

                //textfield for user to enter username
                TextField("Enter email", text: $email)
                    .padding(.leading, 40)
                    .padding(.trailing, 40)
                    .padding(.bottom, 25)
                    .textFieldStyle(.roundedBorder)
                    .offset(y: -50)
                    
                // secure field for user to enter password
                SecureField("Enter password", text: $password)
                    .padding(.leading, 40)
                    .padding(.trailing, 40)
                    .padding(.bottom, 30)
                    .textFieldStyle(.roundedBorder)
                    .offset(y: -40)
                    
                HStack() {
                        
                    Spacer()
                        
                    // button that will allow user to login
                    Button(action: {
                            
                        // if the function validateEmptyData returns true, user will be able to login
                        if (self.validateEmptyData()){
                            
                            createUser()
            

                        }
                            
                        // if function returned false, error message shown to user
                        else {
                                
                            self.alertTitle = "Error"
                            self.alertMessage = "All fields are required"
                            self.invalidSignUp = true

                        }
                            
                    }, label: {
                        // sets label for button
                        Text("Sign Up")
                            .foregroundColor(Color.black)
                            .font(.body)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .frame(width: 200 , height: 50, alignment: .center)
                    })
                        .background(Color(red: 196/255, green: 234/255, blue: 253/255))
                        .cornerRadius(10)
                        .offset(y: -30)
                        .alert (isPresented: self.$invalidSignUp){
                            // sets text of the alert message and the dismiss button
                            Alert(
                                title: Text(self.alertTitle),
                                message: Text(self.alertMessage),
                                dismissButton: .default(Text("Ok"))
                            )
                        }
                        
                    Spacer()
                        
                } //HStack
                .listRowBackground(Color.clear)
                
                Text(self.loginStatusMessage)
                    .foregroundColor(.red)
                
                // provides link to sign up view for users to create an account
                HStack {
                    Text("Already have an account?")
                    Text("Login")
                        .foregroundColor(.blue)
                        .underline()
                        .onTapGesture {
                            isLoginTapped = true;
                        }
                    NavigationLink("", destination: LoginView() .navigationBarHidden(true), isActive: $isLoginTapped)
                } // HStack
                .padding(30)
                .offset(y: 35)
                
            } // VStack
        
        //} // navigation view
        
    } // body
    
    // function that checks if user input both name and password
    private func validateEmptyData() -> Bool{
        if (self.firstName.isEmpty || self.lastName.isEmpty || self.email.isEmpty || self.password.isEmpty){
            return false
        }
        return true
    }
    
    // function that handles creating a user
    private func createUser() {
        
        // creates new user in firebase authentication
        Auth.auth().createUser(withEmail: email, password: password) {
            result, err in
            
            // if an error occured, print to console and update loginStatusMessage variable
            if let err = err {
                print("failed to create user:", err)
                self.loginStatusMessage = "Failed to create user: \(err)"
                return
            }
            
            // if successful, print success message to console and update loginStatusMessage variable
            print("created user: \(result?.user.uid ?? "")")
            self.loginStatusMessage = "Successfully created user!"
        }
    }

}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
