//
//  ContentView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI
import CoreData
import Firebase

// login view
struct LoginView: View {
    
    @EnvironmentObject var viewModel : LoginManager
    
    // variable to store email entered by user
    @State private var email: String = ""
    
    // variable to store password entered by user
    @State private var password: String  = ""
    
    // variable to hold value of the alert message
    @State private var alertMessage : String = ""
    
    // variable to hold value of alert title
    @State private var alertTitle: String = ""
    
    // variable to hold value of an invalid login
    @State private var invalidLogin: Bool = false
    
    // variable to hold value of if the sign up link is tapped or not
    @State private var isSignUpTapped: Bool = false
    
    // variable to hold value of selection
    @State private var selection: Int? = nil
    
    // variable that holds value of login status
    @State var loginStatusMessage = ""
    
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        
       // NavigationView {
            
            VStack {
                
                // creates navigation link to spending view
                NavigationLink(destination: NavigationBarView().navigationBarBackButtonHidden(true), tag: 1, selection: $selection) {}
                
                // adds the logo image to top of view
                Image("cents logo")
                    .resizable()
                    .frame(width: 150, height: 150)
                    .padding(.bottom, 30)
                    .offset(y: -130)
                
                // welcome text
                Text("Welcome!")
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 40)
                    .font(.system(size: 25))
                    .offset(y: -90)
                
                // login text
                Text("Login")
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 40)
                    .font(.system(size: 35))
                    .offset(y: -80)
                    
                //textfield for user to enter username
                TextField("Enter email", text: $email)
                    .padding(.leading, 40)
                    .padding(.trailing, 40)
                    .padding(.bottom, 25)
                    .textFieldStyle(.roundedBorder)
                    .offset(y: -60)
                    
                // secure field for user to enter password
                SecureField("Enter password", text: $password)
                    .padding(.leading, 40)
                    .padding(.trailing, 40)
                    .padding(.bottom, 30)
                    .textFieldStyle(.roundedBorder)
                    .offset(y: -50)
                    
                HStack() {
                        
                    Spacer()
                        
                    // button that will allow user to login
                    Button(action: {
                            
                        // if the function validateEmptyData returns true, user will be able to login
                        if (self.validateEmptyData()){
                            loginUser()
                        }
                            
                        // if function returned false, error message shown to user
                        else {
                                
                            self.alertTitle = "Error"
                            self.alertMessage = "Username and password are required"
                            self.invalidLogin = true

                        }
                            
                    }, label: {
                        // sets label for button
                        Text("Login")
                            .foregroundColor(Color.black)
                            .font(.body)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .frame(width: 200 , height: 50, alignment: .center)
                    })
                        .background(Color(red: 196/255, green: 234/255, blue: 253/255))
                        .cornerRadius(10)
                        .offset(y: -30)
                        .alert (isPresented: self.$invalidLogin){
                            // sets text of the alert message and the dismiss button
                            Alert(
                                title: Text(self.alertTitle),
                                message: Text(self.alertMessage),
                                dismissButton: .default(Text("Ok"))
                            )
                        }
                        
                    Spacer()
                        
                } //HStack
                .listRowBackground(Color.clear)
                
                Text(self.loginStatusMessage)
                    .foregroundColor(.red)
                
                // provides link to sign up view for users to create an account
                HStack {
                    Text("Don't already have an account?")
                    Text("Sign Up")
                        .foregroundColor(.blue)
                        .underline()
                        .onTapGesture {
                            isSignUpTapped = true;
                        }
                    NavigationLink("", destination: SignUpView() .navigationBarHidden(true), isActive: $isSignUpTapped)
       
                } // HStack
                .padding(30)
                .offset(y: 90)
                
            } // VStack
        
       // } // navigation view
        
        //.navigationViewStyle(StackNavigationViewStyle())
        
    } // body
    
    // function that checks if user input both name and password
    private func validateEmptyData() -> Bool{
        if (self.email.isEmpty || self.password.isEmpty){
            return false
        }
        return true
    }
    
    private func loginUser() {
        // signs in user in firebase authentication
        Auth.auth().signIn(withEmail: email, password: password) {
            result, err in
            
            // if an error occured, print to console and update loginStatusMessage variable
            if let err = err {
                print("failed to login user:", err)
                self.loginStatusMessage = "Failed to login user: \(err)"
                return
            }
            
            // if successful, print success message to console and update loginStatusMessage variable
            print("logged in user: \(result?.user.uid ?? "")")
            viewModel.isLoggedIn = true
            //self.loginStatusMessage = "Successfully logged in!"
        }

    }

}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
