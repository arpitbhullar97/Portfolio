//
//  NavigationBarView.swift
//  PROG31975 Project
//
//  GROUP 1
//  Christina Zammit 991585165
//  Arpit Bhullar 991424651
//
//  Christina Zammit
//

import SwiftUI

struct NavigationBarView: View {
    
    // creates instance of LoginManager class
    @EnvironmentObject var viewModel : LoginManager
    
    
    // variable that holds value of the selected tab
    @State private var selection = 2
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        NavigationView {
            
            if (viewModel.isLoggedIn) {
        
                // tab view that will appear at botton of app
                TabView (selection:$selection) {
                    
                    // tab that, when clicked, takes user to expenses view
                    ExpensesView()
                        .tabItem {
                            Image(systemName: "creditcard")
                            Text("Expenses")
                        }
                        .tag(1)
                    
                    // tab that, when clicked, takes user to spending view
                    SpendingView()
                        .tabItem {
                            Image(systemName: "dollarsign.circle")
                            Text("Spending")
                        }
                        .tag(2)
                        .navigationBarHidden(true)
                    
                    // tab that, when clicked, takes user to budget view
                    BudgetView()
                        .tabItem {
                            Image(systemName: "giftcard")
                            Text("Budget")
                        }
                        .tag(3)
                } // tab view
                
            } // if
            
            else {
                LoginView()
            }
            
        } // nav view
        
    }
    
}
