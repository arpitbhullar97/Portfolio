# PROG31975-Project

## Project Proposal

###### Project UX:
https://preview.uxpin.com/72edcbf1c01149d12205c582d45c7718aebe3cbe

###### Proposed Idea:
We are looking to create an app that allows users to keep track of their spending and finances. The app will allow users to monitor their spending habits, see a breakdown of where they are spending their money most, create budgets that will encourage saving towards a specific goal, and track their expenses. Users will also be reminded when their expense due dates or goal end dates are approaching.

###### Purpose of the App:
Many people have trouble with saving money for long term goals or need extra support when it comes to organizing their expenses and staying on top of expense due dates. This especially true for those who have many monthly expenses or have a number of credit cards with separate due dates. This app will seek to solve those issues. The purpose of the app is to provide users with an all-in-one finance and budgeting app. From within the application, users can track their spending and expenses while also setting budgets for various things, such as a home or a vacation. This can help users stay on top of their spending and will allow them to better manage their money and save towards their goals. 

###### Target Audience:
The target audience for our application will be people who want to better organize their finances and budget their money to save towards their goals. Further, this application will be for people who may have difficulties managing their money on their own and want an all-in-one place to keep track of their expenses and money allocations.

###### Features:
The app contains many features for the users to manage their finances. One such feature includes having the ability to add all transactions into the application so that the user can see how much money they’ve spent in a given amount of time. 
Further, another feature available within the application involves displaying the users’ expenses and bills, such as credit card bills and insurance payments. The app allows users to track these expenses and and view all their due dates for these payments in one place. 
Moreover, the application also provides users with the ability to budget their finances. From within the app, users can set goals for various things, such as a wedding or a vacation. They can set how much money they want to allocate to each budget and can see their progress in regards to how much money they’ve already saved towards each budget and how much money is left to save until the goal is met.
Lastly, this app will feature watchOS functionalities that will present the total spending for the user in all categories. This will allow users to quickly see their total spending on the go.

###### Services and functionalities:
- **WatchOS:** will be used to display the users spending total
- **Pickers:** will allow users to pick dates for their expense due dates and end date for their budgeting goals
- **NavigationView:** will be used to navigate to the various views throughout the application
- **Location services:** when adding a transaction, users will be able to add the location of where the transaction took place
- **Lists:** will be used to display the users’ expenses, transactions, and budgets
- **Firebase Firestore Database:** will be used to store the users’ expenses, transactions, and budgets
- **Firebase Authentication:** will be used to create user accounts and the sign up and login functionalities

###### Use-cases:
The first use-case present in our application will be giving users the ability to add their transactions. When a user adds a transaction, they’ll have the ability to add the location of where that transaction took place. If the transaction includes saving money towards a budget, the user will be able to add, from a picker, which budget it will be allocated towards. WatchOS will also be used to display the users total spending in all categories.
The second use-case of our application will be to manage expenses. Users will have the ability to add their expenses, such as credit card bills and insurance payments, to the application so that they can keep track of due dates and can also see the total amount owed.
Lastly, the third use-case of our application will be budgeting. Users will be able to add a budget with an end date and set a goal of how much money they want to save towards that goal. Users can indicate from within the application that they are saving a certain amount of money towards a budget. When this is done, the amount left to meet that budget’s goal will decrease and the user will also be able to see how much money overall they’ve saved towards that goal.

###### App Preview:
<img width="353" alt="Screen Shot 2021-12-11 at 8 03 48 PM" src="https://user-images.githubusercontent.com/68960617/145696845-a13e90ac-c6b6-4f5f-9cd4-6d4436b84394.png">   <img width="349" alt="Screen Shot 2021-12-11 at 8 03 59 PM" src="https://user-images.githubusercontent.com/68960617/145696851-d51125c4-7115-4f5b-aff0-55842aaefcbf.png"> 

The functionalities behind the login and sign up screens were created using Firebase Authentication. Upon starting the app, users are presented with the login screen where an existing user can login to their account and new users can click the "sign up" link at the bottom of the page to be navigated to the sign up screen to create an account as a new user.

<img width="341" alt="Screen Shot 2021-12-11 at 8 07 20 PM" src="https://user-images.githubusercontent.com/68960617/145696888-4cbe6409-2dfa-444e-9569-fc087df7515a.png"> <img width="345" alt="Screen Shot 2021-12-11 at 8 07 42 PM" src="https://user-images.githubusercontent.com/68960617/145696949-15f56960-e84e-46ba-ad2a-088748ee362e.png">

Once logged in, the users are presented with the spending screen where they can view a graphical breakdown of how much money they've spent in each category. Below the graph, users can view the exact amount they spend in each category. When a category is clicked, users are taken to a screen where they can view every transaction they made in each of the corresponding categories.

<img width="247" alt="Screen Shot 2021-12-14 at 10 40 16 PM" src="https://user-images.githubusercontent.com/68960617/146119018-c203df34-8ce3-4929-a4f3-88296420c785.png">

The Cents app also has WatchOS functionalities, in which it displays the logged in users spending total at quick glance.

<img width="339" alt="Screen Shot 2021-12-11 at 8 06 57 PM" src="https://user-images.githubusercontent.com/68960617/145696957-aab2e075-54af-47c8-9234-bceb8e48ebf7.png">

In the navigation bar of the spending screen, an 'Add' button is presented to the users that will navigate them to a view where they will be able to add a new transaction. Users will be able to input data such as the date the transaction was made, the category the transaction falls under, and the amount they spent. Users are also given the option to add a location for their transaction.

 <img width="338" alt="Screen Shot 2021-12-11 at 8 06 39 PM" src="https://user-images.githubusercontent.com/68960617/145696985-0ff44c48-65de-4a29-a247-25e886074fd7.png"> <img width="344" alt="Screen Shot 2021-12-11 at 8 06 46 PM" src="https://user-images.githubusercontent.com/68960617/145696987-99d64d6a-37d2-400b-8e9c-4d948769b3bb.png">
 
 When a user chooses to add a location to their transaction, they are taken to a mapview where they can view their current location and a search bar on top where they can search for nearby landmarks. When a user searches for nearby places on the map, the map will populate with placemarks and a list will be visible at the bottom of the screen to view a list of the landmark addresses.

Similarly, in the navigation bar of the expenses screen, an 'Add' button is displayed to allow users to enter new payments that are due from three categories - credit card, insurance and other bills, along with the due date, the amount. For the credit card category users are given the option to choose what card the payment is due for. Below screenshots depict the same:
<img width="339" alt="Screen Shot 2021-12-16 at 1 19 05 AM" src="https://user-images.githubusercontent.com/93418400/146256249-0a7618e0-15c4-435c-a9d5-e99a8c8d4a52.png">

The expense view shows all three categories of expenses as a list which is clickable as seen below:
<img width="339" alt="Screen Shot 2021-12-16 at 1 18 48 AM" src="https://user-images.githubusercontent.com/93418400/146256573-670b3475-1e37-4f35-8b33-f62db7027509.png">
<img width="339" alt="Screen Shot 2021-12-16 at 1 34 32 AM" src="https://user-images.githubusercontent.com/93418400/146257189-6db0eee9-66e2-4d50-8a5b-d24f2d517355.png">

<img width="339" alt="Screen Shot 2021-12-16 at 1 19 19 AM" src="https://user-images.githubusercontent.com/93418400/146256606-81ccbbee-5258-4139-a719-f5c4e2e7541e.png">

The Budget view displays the total amount saved for all user saved categories (hard coded in our case) 
<img width="339" alt="Screen Shot 2021-12-16 at 1 20 02 AM" src="https://user-images.githubusercontent.com/93418400/146256760-83a21170-f19f-4604-82cf-b5c3386da053.png">

###### Work distribution:
- Christina Zammit, 991585165: First use-case, UI/UX design, database management, user management, location services, watchOS
- Arpit Bhullar, 991424651: Second use-case, third use-case
